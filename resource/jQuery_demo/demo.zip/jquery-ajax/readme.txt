Notes on this tutorial:

Background images in tutorial.css file may need to be referenced as ../images/filename for them to show when you run the demo.

The phpmailer.php script in /bin does not need adjustment.

The process.php file in /bin does need adjustment to send an email correctly.   At a minimum, you need to change the $to, $email, $fromaddress, and $mail->From to get it to work.

For more information on phpmailer, go to http://phpmailer.codeworxtech.com/.

Finally, you have my permission to use any of the included images, if you would like.  I did grab the cancel.png off a previous tutorial at nettuts.com so you might want to inquire with nettuts as to if you can use that one.  check.png was included with a free icon set that I got from http://www.wefunction.com/function-free-icon-set.

If you have any questions feel free to contact me:

eric@renkai.com
